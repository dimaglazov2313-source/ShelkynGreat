using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

public static class BuildGameScene
{
    [MenuItem("Щелкун Великий/Создать игровую сцену")]
    public static void CreateScene()
    {
        Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
        GameObject bootstrap = new GameObject("Game Bootstrap");
        bootstrap.AddComponent<GameBootstrap>();
        EditorSceneManager.SaveScene(scene, "Assets/SchelkuncGame.unity");
        EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene("Assets/SchelkuncGame.unity", true) };
        Debug.Log("Сцена создана: Assets/SchelkuncGame.unity. Нажми Play!");
    }
}
