using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 6f;
    public float turnSpeed = 140f;
    public int health = 100;
    public int maxHealth = 100;
    public int weaponIndex = 0;
    public int[] ammo = { 120, 48, 240 };
    public float[] damage = { 22f, 65f, 15f };
    public float[] fireDelay = { 0.28f, 0.85f, 0.09f };
    public float[] range = { 35f, 18f, 45f };
    public string[] weaponNames = { "Пистолет", "Дробовик", "Автомат" };

    CharacterController controller;
    float verticalVelocity;
    float nextShot;
    Vector2 mobileMove;
    float mobileTurn;

    void Awake() { controller = GetComponent<CharacterController>(); }

    void Update()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        mobileTurn = 0;

        // Left half of the screen acts as a simple virtual joystick.
        if (Input.touchCount > 0)
        {
            foreach (Touch t in Input.touches)
            {
                if (t.position.x < Screen.width * 0.48f)
                {
                    if (t.phase == TouchPhase.Began) mobileMove = Vector2.zero;
                    mobileMove = new Vector2(
                        Mathf.Clamp((t.position.x - Screen.width * 0.22f) / (Screen.width * 0.18f), -1, 1),
                        Mathf.Clamp((t.position.y - Screen.height * 0.22f) / (Screen.height * 0.18f), -1, 1));
                }
                else if (t.phase == TouchPhase.Moved)
                {
                    mobileTurn = t.deltaPosition.x * 0.12f;
                }
            }
        }
        else mobileMove = Vector2.zero;

        if (mobileMove.sqrMagnitude > 0.01f) { h = mobileMove.x; v = mobileMove.y; }

        transform.Rotate(Vector3.up, (Input.GetAxis("Mouse X") * turnSpeed * Time.deltaTime) + mobileTurn);
        Vector3 move = transform.forward * v + transform.right * h;
        if (move.magnitude > 1) move.Normalize();

        if (controller.isGrounded) verticalVelocity = -1f;
        else verticalVelocity -= 20f * Time.deltaTime;

        move.y = verticalVelocity;
        controller.Move(move * moveSpeed * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.Alpha1)) weaponIndex = 0;
        if (Input.GetKeyDown(KeyCode.Alpha2) && GameManager.Instance != null && GameManager.Instance.kills >= 8) weaponIndex = 1;
        if (Input.GetKeyDown(KeyCode.Alpha3) && GameManager.Instance != null && GameManager.Instance.kills >= 20) weaponIndex = 2;

        if (Input.GetMouseButton(0) || Input.GetKey(KeyCode.Space)) Fire();
    }

    public void Fire()
    {
        if (Time.time < nextShot || ammo[weaponIndex] <= 0) return;
        nextShot = Time.time + fireDelay[weaponIndex];
        ammo[weaponIndex]--;

        Vector3 origin = transform.position + Vector3.up * 1.25f + transform.forward * 0.5f;
        Ray ray = new Ray(origin, transform.forward);
        RaycastHit hit;
        if (Physics.Raycast(ray, out hit, range[weaponIndex]))
        {
            EnemyAI enemy = hit.collider.GetComponentInParent<EnemyAI>();
            if (enemy != null) enemy.TakeDamage(damage[weaponIndex]);
        }
    }

    public void TakeDamage(int amount)
    {
        health = Mathf.Max(0, health - amount);
        if (health <= 0 && GameManager.Instance != null) GameManager.Instance.GameOver();
    }

    public void Heal(int amount) { health = Mathf.Min(maxHealth, health + amount); }
    public void Reload() { ammo[weaponIndex] += weaponIndex == 1 ? 12 : 45; }
}
