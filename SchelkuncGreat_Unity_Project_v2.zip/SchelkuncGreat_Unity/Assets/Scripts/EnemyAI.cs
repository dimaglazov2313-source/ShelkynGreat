using UnityEngine;

public class EnemyAI : MonoBehaviour
{
    public float health = 55f;
    public float speed = 2.1f;
    public int damage = 8;
    public float attackDistance = 1.7f;
    public float attackCooldown = 1.2f;
    public bool isBoss;
    public string enemyName = "Заражённый";
    Transform target;
    float nextAttack;
    GameObject healthBar;

    void Start()
    {
        if (GameObject.FindWithTag("Player") != null) target = GameObject.FindWithTag("Player").transform;
        if (target == null)
        {
            PlayerController p = FindObjectOfType<PlayerController>();
            if (p != null) target = p.transform;
        }
        if (isBoss) CreateBossBar();
    }

    void Update()
    {
        if (target == null) return;
        Vector3 delta = target.position - transform.position;
        delta.y = 0;
        float distance = delta.magnitude;
        if (distance > attackDistance)
        {
            transform.position += delta.normalized * speed * Time.deltaTime;
            if (delta.sqrMagnitude > 0.01f) transform.rotation = Quaternion.LookRotation(delta);
        }
        else if (Time.time >= nextAttack)
        {
            nextAttack = Time.time + attackCooldown;
            PlayerController player = target.GetComponent<PlayerController>();
            if (player != null) player.TakeDamage(damage);
        }
    }

    public void TakeDamage(float amount)
    {
        health -= amount;
        if (health <= 0)
        {
            if (GameManager.Instance != null) GameManager.Instance.EnemyKilled(this);
            Destroy(gameObject);
        }
    }

    void CreateBossBar()
    {
        GameObject bar = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bar.name = "Полоса босса";
        bar.transform.SetParent(transform);
        bar.transform.localPosition = Vector3.up * 2.5f;
        bar.transform.localScale = new Vector3(1.5f, 0.12f, 0.12f);
        bar.GetComponent<Collider>().enabled = false;
        bar.GetComponent<Renderer>().material.color = Color.red;
        healthBar = bar;
    }
}
