using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target;
    public Vector3 thirdPersonOffset = new Vector3(0, 5, -7);
    public float smooth = 10f;
    public bool firstPerson;
    Renderer[] playerRenderers;

    void Start()
    {
        if (target != null) playerRenderers = target.GetComponentsInChildren<Renderer>();
        ApplyVisibility();
    }

    void LateUpdate()
    {
        if (target == null) return;

        Vector3 desired;
        if (firstPerson)
        {
            desired = target.position + Vector3.up * 1.55f + target.forward * 0.12f;
            transform.position = Vector3.Lerp(transform.position, desired, smooth * Time.deltaTime);
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(target.forward, Vector3.up), smooth * Time.deltaTime);
        }
        else
        {
            desired = target.position + target.rotation * thirdPersonOffset;
            transform.position = Vector3.Lerp(transform.position, desired, smooth * Time.deltaTime);
            transform.LookAt(target.position + Vector3.up * 1.2f);
        }
    }

    public void ToggleCamera()
    {
        firstPerson = !firstPerson;
        ApplyVisibility();
    }

    void ApplyVisibility()
    {
        if (playerRenderers == null) return;
        foreach (Renderer r in playerRenderers) r.enabled = !firstPerson;
    }
}
