using UnityEngine;

public class GameBootstrap : MonoBehaviour
{
    void Start()
    {
        BuildWorld();
    }

    void BuildWorld()
    {
        RenderSettings.ambientLight = new Color(0.28f, 0.30f, 0.32f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.16f, 0.18f, 0.20f);
        RenderSettings.fogDensity = 0.012f;

        GameObject sun = new GameObject("Moonlight");
        Light light = sun.AddComponent<Light>();
        light.type = LightType.Directional;
        light.intensity = 0.65f;
        sun.transform.rotation = Quaternion.Euler(45, -30, 0);

        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Заброшенная территория";
        ground.transform.localScale = new Vector3(12, 1, 12);
        ground.GetComponent<Renderer>().material = MakeMaterial(new Color(0.20f, 0.22f, 0.19f));

        // Ruined buildings and cover
        for (int i = 0; i < 22; i++)
        {
            Vector3 p = new Vector3(Random.Range(-48, 48), 0, Random.Range(-48, 48));
            if (p.magnitude < 12) continue;
            GameObject block = GameObject.CreatePrimitive(PrimitiveType.Cube);
            block.name = "Развалины";
            block.transform.position = p + Vector3.up * Random.Range(1.5f, 3f);
            block.transform.localScale = new Vector3(Random.Range(3f, 8f), Random.Range(3f, 6f), Random.Range(3f, 8f));
            block.GetComponent<Renderer>().material = MakeMaterial(new Color(0.25f, 0.25f, 0.24f));
        }

        GameObject player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        player.name = "Игрок";
        player.transform.position = new Vector3(0, 1, 0);
        player.GetComponent<Renderer>().material = MakeMaterial(new Color(0.15f, 0.55f, 0.85f));
        CapsuleCollider oldCollider = player.GetComponent<CapsuleCollider>();
        Destroy(oldCollider);
        CharacterController cc = player.AddComponent<CharacterController>();
        cc.height = 2f;
        cc.radius = 0.45f;
        player.AddComponent<PlayerController>();

        Camera cam = Camera.main;
        if (cam == null)
        {
            GameObject cameraObject = new GameObject("Main Camera");
            cam = cameraObject.AddComponent<Camera>();
            cameraObject.tag = "MainCamera";
        }
        cam.transform.position = new Vector3(0, 5, -8);
        cam.transform.rotation = Quaternion.Euler(20, 0, 0);
        CameraFollow follow = cam.gameObject.AddComponent<CameraFollow>();
        follow.target = player.transform;

        GameObject manager = new GameObject("Game Manager");
        manager.AddComponent<GameManager>();

        GameObject lightObj = new GameObject("Player light");
        Light playerLight = lightObj.AddComponent<Light>();
        playerLight.type = LightType.Point;
        playerLight.range = 18;
        playerLight.intensity = 1.2f;
        lightObj.transform.SetParent(player.transform);
        lightObj.transform.localPosition = new Vector3(0, 3, 0);
    }

    Material MakeMaterial(Color color)
    {
        Material m = new Material(Shader.Find("Standard"));
        m.color = color;
        return m;
    }
}
