using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public int kills;
    public int wave = 1;
    public bool gameOver;
    int alive;
    int bossIndex;
    bool bossActive;
    int nextBossKill = 12;
    float spawnTimer;
    PlayerController player;
    string message = "Выживи. Уничтожай заражённых.";

    readonly string[] bosses = { "ВАСЮК", "СЕРИГА", "ИГОРЬ", "ЩЕЛКУН ВЕЛИКИЙ", "СЕКРЕТНЫЙ БОСС: ТЕНЬ" };

    void Awake() { Instance = this; }

    void Start()
    {
        player = FindObjectOfType<PlayerController>();
        for (int i = 0; i < 5; i++) SpawnEnemy(false);
    }

    void Update()
    {
        if (gameOver) return;
        spawnTimer += Time.deltaTime;
        if (spawnTimer > Mathf.Max(1.3f, 5f - wave * 0.25f) && alive < 5 + wave)
        {
            spawnTimer = 0;
            SpawnEnemy(false);
        }
        if (kills >= wave * 12)
        {
            wave++;
            message = "ВОЛНА " + wave + " — враги стали сильнее!";
        }
        if (!bossActive && bossIndex < bosses.Length && kills >= nextBossKill)
        {
            bossActive = true;
            SpawnEnemy(true);
        }
        if (Input.GetKeyDown(KeyCode.R)) player.Reload();
    }

    void SpawnEnemy(bool boss)
    {
        Vector2 circle = Random.insideUnitCircle.normalized * Random.Range(16f, 30f);
        Vector3 pos = (player != null ? player.transform.position : Vector3.zero) + new Vector3(circle.x, 0.9f, circle.y);
        GameObject enemy = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        enemy.transform.position = pos;
        enemy.name = boss ? "Босс" : "Заражённый";
        EnemyAI ai = enemy.AddComponent<EnemyAI>();
        ai.isBoss = boss;
        ai.health = boss ? 900 + bossIndex * 350 : 45 + wave * 12;
        ai.speed = boss ? 2.4f + bossIndex * 0.2f : 1.8f + wave * 0.08f;
        ai.damage = boss ? 22 + bossIndex * 5 : 5 + wave * 2;
        if (boss)
        {
            bossActive = true;
            ai.enemyName = bosses[Mathf.Min(bossIndex, bosses.Length - 1)];
            enemy.transform.localScale = new Vector3(2.4f, 2.4f, 2.4f);
            enemy.GetComponent<Renderer>().material.color = new Color(0.55f, 0.05f, 0.08f);
            message = "БОСС: " + ai.enemyName;
        }
        else
        {
            enemy.GetComponent<Renderer>().material.color = new Color(0.35f, 0.48f, 0.28f);
        }
        alive++;
    }

    public void EnemyKilled(EnemyAI enemy)
    {
        kills++;
        alive = Mathf.Max(0, alive - 1);
        if (enemy.isBoss)
        {
            bossActive = false;
            bossIndex++;
            nextBossKill = kills + 18;
            message = "БОСС ПОВЕРЖЕН! Получено улучшение.";
            if (player != null)
            {
                player.Heal(35);
                if (bossIndex >= 1) player.weaponIndex = 1;
                if (bossIndex >= 2) player.weaponIndex = 2;
            }
            if (bossIndex >= bosses.Length) message = "ТЫ ПОБЕДИЛ ВСЕХ БОССОВ!";
        }
        else if (kills % 8 == 0 && player != null)
        {
            player.Heal(15);
            message = "Аптечка найдена: +15 здоровья";
        }
    }

    public void GameOver() { gameOver = true; message = "ТЫ ПОГИБ. Нажми кнопку перезапуска."; }

    void OnGUI()
    {
        GUI.skin.label.fontSize = Mathf.Max(16, Screen.width / 45);
        GUI.skin.button.fontSize = Mathf.Max(16, Screen.width / 48);
        if (player != null)
        {
            GUI.Label(new Rect(18, 14, 420, 35), "ЗДОРОВЬЕ: " + player.health + " / " + player.maxHealth);
            GUI.Label(new Rect(18, 48, 420, 35), "ВОЛНА: " + wave + "   УБИЙСТВА: " + kills);
            GUI.Label(new Rect(18, 82, 500, 35), player.weaponNames[player.weaponIndex] + "   ПАТРОНЫ: " + player.ammo[player.weaponIndex]);
        }
        GUI.Label(new Rect(18, Screen.height - 50, Screen.width - 36, 40), message);

        float bw = 125, bh = 52;
        if (GUI.Button(new Rect(Screen.width - bw - 18, Screen.height - bh - 18, bw, bh), "СТРЕЛЯТЬ") && player != null) player.Fire();
        if (GUI.Button(new Rect(Screen.width - bw - 18, Screen.height - bh * 2 - 28, bw, bh), "ОРУЖИЕ") && player != null)
        {
            int max = kills >= 20 ? 3 : (kills >= 8 ? 2 : 1);
            player.weaponIndex = (player.weaponIndex + 1) % max;
        }
        if (GUI.Button(new Rect(Screen.width - bw - 18, 18, bw, bh), "ПЕРЕЗАРЯДКА") && player != null) player.Reload();
        if (GUI.Button(new Rect(18, 124, bw + 35, bh), "СМЕНИТЬ КАМЕРУ"))
        {
            CameraFollow cameraFollow = Camera.main != null ? Camera.main.GetComponent<CameraFollow>() : null;
            if (cameraFollow != null) cameraFollow.ToggleCamera();
        }
        if (gameOver && GUI.Button(new Rect(Screen.width / 2 - 90, Screen.height / 2 - 25, 180, 55), "ЗАНОВО"))
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().buildIndex);
        }
    }
}
